; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"

; Function Attrs: nounwind readnone 
declare <256 x i8> @llvm.hivm.vintlvv2.v256s8(<256 x i8>, <256 x i8>, i32) #0

; Function Attrs: noduplicate noinline willreturn
define internal ptc_simdvf void @shuffle(ptr addrspace(6) noalias %0, ptr addrspace(6) noalias %1) #1 {
  %3 = call <256 x i8> @llvm.hivm.vldsx1.v256s8(ptr addrspace(6) %0, i32 0, i32 0, i32 0)
  %4 = call <256 x i8> @llvm.hivm.vintlvv2.v256i8(<256 x i8> %3, <256 x i8> %3, i32 0)
  %5 = bitcast <256 x i8> %4 to <128 x i16>
  %6 = call <128 x i16> @llvm.hivm.vdintlvv2.v128i16(<128 x i16> %5, <128 x i16> %5, i32 1)
  %7 = bitcast <128 x i16> %6 to <64 x i32>
  %8 = call <64 x i32> @llvm.hivm.vdintlvv2.v64i32(<64 x i32> %7, <64 x i32> %7, i32 0)
  %9 = call <64 x i32> @llvm.hivm.vdintlvv2.v64i32(<64 x i32> %7, <64 x i32> %7, i32 1)
  %10 = insertvalue { <64 x i32>, <64 x i32> } poison, <64 x i32> %8, 0
  %11 = insertvalue { <64 x i32>, <64 x i32> } %10, <64 x i32> %9, 1
  %12 = extractvalue { <64 x i32>, <64 x i32> } %11, 1
  %13 = bitcast <64 x i32> %12 to <64 x float>
  %14 = call <64 x float> @llvm.hivm.vintlvv2.v64f32(<64 x float> %13, <64 x float> %13, i32 1)
  %15 = bitcast <64 x float> %14 to <256 x i8>
  %16 = call <256 x i1> @llvm.hivm.pge.b8(i32 0, i32 0)
  call void @llvm.hivm.vstsx1.v256s8(<256 x i8> %15, ptr addrspace(6) %1, i32 0, i32 3, i32 0, <256 x i1> %16)
  ret void
}

define dso_local void @kernel(i64 %0, i64 %1) #2 {
  %3 = inttoptr i64 %0 to ptr addrspace(6)
  %4 = inttoptr i64 %1 to ptr addrspace(6)
  call ptc_simdvf void @shuffle(ptr addrspace(6) %3, ptr addrspace(6) %4)
  ret void
}

; Function Attrs: nounwind readonly 
declare <256 x i8> @llvm.hivm.vldsx1.v256s8(ptr addrspace(6) nocapture readonly, i32, i32, i32) #3

; Function Attrs: nounwind readnone 
declare <256 x i8> @llvm.hivm.vintlvv2.v256i8(<256 x i8>, <256 x i8>, i32) #0

; Function Attrs: nounwind readnone 
declare <128 x i16> @llvm.hivm.vdintlvv2.v128i16(<128 x i16>, <128 x i16>, i32) #0

; Function Attrs: nounwind readnone 
declare <64 x i32> @llvm.hivm.vdintlvv2.v64i32(<64 x i32>, <64 x i32>, i32) #0

; Function Attrs: nounwind readnone 
declare <64 x float> @llvm.hivm.vintlvv2.v64f32(<64 x float>, <64 x float>, i32) #0

; Function Attrs: nounwind
declare <256 x i1> @llvm.hivm.pge.b8(i32, i32) #4

; Function Attrs: nounwind writeonly 
declare void @llvm.hivm.vstsx1.v256s8(<256 x i8>, ptr addrspace(6) nocapture readonly, i32, i32, i32, <256 x i1>) #5

attributes #0 = { nounwind readnone  }
attributes #1 = { noduplicate noinline willreturn "target-cpu"="dav-920r1" "target-features"="+dav-920r1" }
attributes #2 = { "target-cpu"="dav-920r1" "target-features"="+dav-920r1" "vec-only-kernel" }
attributes #3 = { nounwind readonly  }
attributes #4 = { nounwind }
attributes #5 = { nounwind writeonly  }

!llvm.module.flags = !{!0}
!hivm.annotations = !{!1}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{ptr @kernel, !"kernel", i32 1}

