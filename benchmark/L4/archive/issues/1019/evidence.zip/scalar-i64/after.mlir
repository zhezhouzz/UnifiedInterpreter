module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">} {
  func.func @choose_i64(%arg0: i1, %arg1: i64, %arg2: i64) -> i64 attributes {hivm.vector_function} {
    %0 = llvm.freeze %arg1 : i64
    %1 = llvm.freeze %arg2 : i64
    %2 = arith.extsi %arg0 : i1 to i64
    %3 = arith.xori %0, %1 : i64
    %4 = arith.andi %2, %3 : i64
    %5 = arith.xori %1, %4 : i64
    return %5 : i64
  }
  func.func @choose_i32(%arg0: i1, %arg1: i32, %arg2: i32) -> i32 attributes {hivm.vector_function} {
    %0 = arith.select %arg0, %arg1, %arg2 : i32
    return %0 : i32
  }
  func.func @choose_si64(%arg0: i1, %arg1: si64, %arg2: si64) -> si64 attributes {hivm.vector_function} {
    %0 = arith.select %arg0, %arg1, %arg2 : si64
    return %0 : si64
  }
  func.func @scalar_caller(%arg0: i1, %arg1: i64, %arg2: i64) -> i64 {
    %0 = arith.select %arg0, %arg1, %arg2 : i64
    return %0 : i64
  }
}

