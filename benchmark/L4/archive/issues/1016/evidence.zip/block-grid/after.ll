; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"

define dso_local void @clear_block(ptr addrspace(1) %0, ptr addrspace(1) %1, ptr addrspace(1) %2, i32 %3, i32 %4, i32 %5) #0 {
  %7 = call i64 @llvm.hivm.GET.CTRL()
  %8 = call i64 @llvm.hivm.SBITSET0(i64 %7, i64 60)
  call void @llvm.hivm.SET.CTRL(i64 %8)
  %9 = call i64 @llvm.hivm.GET.CTRL()
  %10 = call i64 @llvm.hivm.SBITSET1(i64 %9, i64 48)
  call void @llvm.hivm.SET.CTRL(i64 %10)
  %11 = mul i32 %3, %4
  %12 = mul i32 %11, %5
  %13 = call i64 @llvm.hivm.GET.BLOCK.IDX()
  %14 = trunc i64 %13 to i32
  br label %15

15:                                               ; preds = %18, %6
  %16 = phi i32 [ %27, %18 ], [ %14, %6 ]
  %17 = icmp slt i32 %16, %12
  br i1 %17, label %18, label %28

18:                                               ; preds = %15
  %19 = srem i32 %16, %3
  %20 = sdiv i32 %16, %3
  %21 = srem i32 %20, %4
  %22 = sext i32 %19 to i64
  %23 = sext i32 %21 to i64
  %24 = mul i64 %23, 4096
  %25 = add i64 %22, %24
  %26 = getelementptr i32, ptr addrspace(1) %2, i64 %25
  store i32 0, ptr addrspace(1) %26, align 4
  %27 = add nsw i32 %16, 64
  br label %15

28:                                               ; preds = %15
  %29 = call i64 @llvm.hivm.GET.CTRL()
  %30 = call i64 @llvm.hivm.SBITSET1(i64 %29, i64 60)
  call void @llvm.hivm.SET.CTRL(i64 %30)
  call void @llvm.hivm.BARRIER(i64 6)
  ret void
}

; Function Attrs: nounwind  inaccessiblememonly
declare i64 @llvm.hivm.GET.CTRL() #1

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.SBITSET0(i64, i64) #2

; Function Attrs: nounwind  inaccessiblememonly
declare void @llvm.hivm.SET.CTRL(i64) #1

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.SBITSET1(i64, i64) #2

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.GET.BLOCK.IDX() #2

; Function Attrs: nounwind  inaccessiblememonly
declare void @llvm.hivm.BARRIER(i64) #1

attributes #0 = { "target-cpu"="dav-920r1" "target-features"="+dav-920r1" "vec-only-kernel" }
attributes #1 = { nounwind  inaccessiblememonly }
attributes #2 = { nounwind readnone  }

!llvm.module.flags = !{!0}
!hivm.annotations = !{!1}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{ptr @clear_block, !"kernel", i32 1}

