; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"

define dso_local void @clear_block(ptr addrspace(1) %0, ptr addrspace(1) %1, ptr addrspace(1) %2, i32 %3, i32 %4, i32 %5) #0 {
  %7 = call i64 @llvm.hivm.GET.CTRL()
  %8 = call i64 @llvm.hivm.SBITSET0(i64 %7, i64 60)
  call void @llvm.hivm.SET.CTRL(i64 %8)
  %9 = call i64 @llvm.hivm.GET.CTRL()
  %10 = call i64 @llvm.hivm.SBITSET1(i64 %9, i64 48)
  call void @llvm.hivm.SET.CTRL(i64 %10)
  %11 = call i64 @llvm.hivm.GET.BLOCK.IDX()
  %12 = trunc i64 %11 to i32
  %13 = srem i32 %12, %3
  %14 = sdiv i32 %12, %3
  %15 = srem i32 %14, %4
  %16 = sext i32 %13 to i64
  %17 = sext i32 %15 to i64
  %18 = mul i64 %17, 4096
  %19 = add i64 %16, %18
  %20 = getelementptr i32, ptr addrspace(1) %2, i64 %19
  store i32 0, ptr addrspace(1) %20, align 4
  %21 = call i64 @llvm.hivm.GET.CTRL()
  %22 = call i64 @llvm.hivm.SBITSET1(i64 %21, i64 60)
  call void @llvm.hivm.SET.CTRL(i64 %22)
  call void @llvm.hivm.BARRIER(i64 6)
  ret void
}

; Function Attrs: nounwind  inaccessiblememonly
declare i64 @llvm.hivm.GET.CTRL() #1

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.SBITSET0(i64, i64) #2

; Function Attrs: nounwind  inaccessiblememonly
declare void @llvm.hivm.SET.CTRL(i64) #1

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.SBITSET1(i64, i64) #2

; Function Attrs: nounwind readnone 
declare i64 @llvm.hivm.GET.BLOCK.IDX() #2

; Function Attrs: nounwind  inaccessiblememonly
declare void @llvm.hivm.BARRIER(i64) #1

attributes #0 = { "target-cpu"="dav-920r1" "target-features"="+dav-920r1" "vec-only-kernel" }
attributes #1 = { nounwind  inaccessiblememonly }
attributes #2 = { nounwind readnone  }

!llvm.module.flags = !{!0}
!hivm.annotations = !{!1}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{ptr @clear_block, !"kernel", i32 1}

