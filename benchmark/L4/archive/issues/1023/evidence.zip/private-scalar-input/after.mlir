module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">, hivm.module_core_type = #hivm.module_core_type<MIX>} {
  func.func private @consume(memref<1xf32, #hivm.address_space<ub>>, f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function}
  func.func private @gate_fused_0(%arg0: f32, %arg1: memref<1xf32, #hivm.address_space<ub>>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function, mix_mode = "aiv", no_inline} {
    %c0 = arith.constant 0 : index
    %0 = vector.constant_mask [1] : vector<64xi1>
    %1 = vector.broadcast %arg0 : f32 to vector<64xf32>
    vector.transfer_write %1, %arg1[%c0], %0 {in_bounds = [true]} : vector<64xf32>, memref<1xf32, #hivm.address_space<ub>>
    return
  }
  func.func @gate_mix_aic(%arg0: memref<1xf32, #hivm.address_space<gm>>) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    return
  }
  func.func @gate_mix_aiv(%arg0: memref<1xf32, #hivm.address_space<gm>>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    %0 = memref.load %arg0[%c0] : memref<1xf32, #hivm.address_space<gm>>
    call @gate_fused_0(%0, %alloc) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function, no_inline} : (f32, memref<1xf32, #hivm.address_space<ub>>) -> ()
    call @consume(%alloc, %0) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xf32, #hivm.address_space<ub>>, f32) -> ()
    return
  }
  func.func @after_call_mix_aic(%arg0: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    memref.store %arg0, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
    return
  }
  func.func @after_call_mix_aiv(%arg0: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    call @consume(%alloc, %arg0) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xf32, #hivm.address_space<ub>>, f32) -> ()
    memref.store %arg0, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
    return
  }
  func.func @prior_iteration_mix_aic(%arg0: index, %arg1: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    scf.for %arg2 = %c0 to %arg0 step %c1 {
      memref.store %arg1, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
    }
    return
  }
  func.func @prior_iteration_mix_aiv(%arg0: index, %arg1: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    scf.for %arg2 = %c0 to %arg0 step %c1 {
      memref.store %arg1, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
      func.call @consume(%alloc, %arg1) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xf32, #hivm.address_space<ub>>, f32) -> ()
    }
    return
  }
  func.func @shared_mix_aic(%arg0: memref<1xf32, #hivm.address_space<gm>>, %arg1: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    memref.store %arg1, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
    %0 = memref.load %alloc[%c0] {hivm.tcore_type = #hivm.tcore_type<CUBE>} : memref<1xf32, #hivm.address_space<ub>>
    memref.store %0, %arg0[%c0] {hivm.tcore_type = #hivm.tcore_type<CUBE>} : memref<1xf32, #hivm.address_space<gm>>
    return
  }
  func.func @shared_mix_aiv(%arg0: memref<1xf32, #hivm.address_space<gm>>, %arg1: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    memref.store %arg1, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
    call @consume(%alloc, %arg1) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xf32, #hivm.address_space<ub>>, f32) -> ()
    return
  }
  func.func private @use_scalars(memref<1xindex, #hivm.address_space<ub>>, memref<1xui8, #hivm.address_space<ub>>, memref<1xi64, #hivm.address_space<ub>>, memref<1xi1, #hivm.address_space<ub>>) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.vector_function}
  func.func @unsupported_types_mix_aic(%arg0: index, %arg1: ui8, %arg2: i64, %arg3: i1) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xindex, #hivm.address_space<ub>>
    %alloc_0 = memref.alloc() : memref<1xui8, #hivm.address_space<ub>>
    %alloc_1 = memref.alloc() : memref<1xi64, #hivm.address_space<ub>>
    %alloc_2 = memref.alloc() : memref<1xi1, #hivm.address_space<ub>>
    memref.store %arg0, %alloc[%c0] : memref<1xindex, #hivm.address_space<ub>>
    memref.store %arg1, %alloc_0[%c0] : memref<1xui8, #hivm.address_space<ub>>
    memref.store %arg2, %alloc_1[%c0] : memref<1xi64, #hivm.address_space<ub>>
    memref.store %arg3, %alloc_2[%c0] : memref<1xi1, #hivm.address_space<ub>>
    return
  }
  func.func @unsupported_types_mix_aiv(%arg0: index, %arg1: ui8, %arg2: i64, %arg3: i1) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xindex, #hivm.address_space<ub>>
    %alloc_0 = memref.alloc() : memref<1xui8, #hivm.address_space<ub>>
    %alloc_1 = memref.alloc() : memref<1xi64, #hivm.address_space<ub>>
    %alloc_2 = memref.alloc() : memref<1xi1, #hivm.address_space<ub>>
    memref.store %arg0, %alloc[%c0] : memref<1xindex, #hivm.address_space<ub>>
    memref.store %arg1, %alloc_0[%c0] : memref<1xui8, #hivm.address_space<ub>>
    memref.store %arg2, %alloc_1[%c0] : memref<1xi64, #hivm.address_space<ub>>
    memref.store %arg3, %alloc_2[%c0] : memref<1xi1, #hivm.address_space<ub>>
    call @use_scalars(%alloc, %alloc_0, %alloc_1, %alloc_2) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xindex, #hivm.address_space<ub>>, memref<1xui8, #hivm.address_space<ub>>, memref<1xi64, #hivm.address_space<ub>>, memref<1xi1, #hivm.address_space<ub>>) -> ()
    return
  }
  func.func @cube_owned_mix_aic(%arg0: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix} {
    %c0 = arith.constant 0 : index
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    scope.scope : () -> () {
      memref.store %arg0, %alloc[%c0] : memref<1xf32, #hivm.address_space<ub>>
      scope.return
    } {hivm.tcore_type = #hivm.tcore_type<CUBE>}
    return
  }
  func.func @cube_owned_mix_aiv(%arg0: f32) attributes {hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix} {
    %alloc = memref.alloc() : memref<1xf32, #hivm.address_space<ub>>
    scope.scope : () -> () {
      func.call @consume(%alloc, %arg0) {hivm.tcore_type = #hivm.tcore_type<VECTOR>, hivm.vector_function} : (memref<1xf32, #hivm.address_space<ub>>, f32) -> ()
      scope.return
    }
    return
  }
}

