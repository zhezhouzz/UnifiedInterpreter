module {
  func.func @test_vadd_v128_f16(%arg0: vector<128xf16>, %arg1: vector<128xf16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%arg0, %arg1, %arg2) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<128xsi16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%arg0, %arg1, %arg2) : (vector<128xsi16>, vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v128_u16(%arg0: vector<128xui16>, %arg1: vector<128xui16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.u.x"(%arg0, %arg1, %arg2) : (vector<128xui16>, vector<128xui16>, vector<256xi1>) -> vector<128xui16>
    "test.test"(%0) : (vector<128xui16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xsi8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%arg0, %arg1, %arg2) : (vector<256xsi8>, vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v256_u8(%arg0: vector<256xui8>, %arg1: vector<256xui8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.u.x"(%arg0, %arg1, %arg2) : (vector<256xui8>, vector<256xui8>, vector<256xi1>) -> vector<256xui8>
    "test.test"(%0) : (vector<256xui8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v64_f32(%arg0: vector<64xf32>, %arg1: vector<64xf32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%arg0, %arg1, %arg2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<64xsi32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.s.x"(%arg0, %arg1, %arg2) : (vector<64xsi32>, vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vadd_v64_u32(%arg0: vector<64xui32>, %arg1: vector<64xui32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vadd.u.x"(%arg0, %arg1, %arg2) : (vector<64xui32>, vector<64xui32>, vector<256xi1>) -> vector<64xui32>
    "test.test"(%0) : (vector<64xui32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v128_f16(%arg0: vector<128xf16>, %arg1: vector<128xf16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%arg0, %arg1, %arg2) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<128xsi16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%arg0, %arg1, %arg2) : (vector<128xsi16>, vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v128_u16(%arg0: vector<128xui16>, %arg1: vector<128xui16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.u.x"(%arg0, %arg1, %arg2) : (vector<128xui16>, vector<128xui16>, vector<256xi1>) -> vector<128xui16>
    "test.test"(%0) : (vector<128xui16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xsi8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%arg0, %arg1, %arg2) : (vector<256xsi8>, vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v256_u8(%arg0: vector<256xui8>, %arg1: vector<256xui8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.u.x"(%arg0, %arg1, %arg2) : (vector<256xui8>, vector<256xui8>, vector<256xi1>) -> vector<256xui8>
    "test.test"(%0) : (vector<256xui8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v64_f32(%arg0: vector<64xf32>, %arg1: vector<64xf32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%arg0, %arg1, %arg2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<64xsi32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.s.x"(%arg0, %arg1, %arg2) : (vector<64xsi32>, vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vmul_v64_u32(%arg0: vector<64xui32>, %arg1: vector<64xui32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vmul.u.x"(%arg0, %arg1, %arg2) : (vector<64xui32>, vector<64xui32>, vector<256xi1>) -> vector<64xui32>
    "test.test"(%0) : (vector<64xui32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v128_f16(%arg0: vector<128xf16>, %arg1: vector<128xf16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%arg0, %arg1, %arg2) : (vector<128xf16>, vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<128xsi16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%arg0, %arg1, %arg2) : (vector<128xsi16>, vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v128_u16(%arg0: vector<128xui16>, %arg1: vector<128xui16>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.u.x"(%arg0, %arg1, %arg2) : (vector<128xui16>, vector<128xui16>, vector<256xi1>) -> vector<128xui16>
    "test.test"(%0) : (vector<128xui16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xsi8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%arg0, %arg1, %arg2) : (vector<256xsi8>, vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v256_u8(%arg0: vector<256xui8>, %arg1: vector<256xui8>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.u.x"(%arg0, %arg1, %arg2) : (vector<256xui8>, vector<256xui8>, vector<256xi1>) -> vector<256xui8>
    "test.test"(%0) : (vector<256xui8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v64_f32(%arg0: vector<64xf32>, %arg1: vector<64xf32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%arg0, %arg1, %arg2) : (vector<64xf32>, vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<64xsi32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.s.x"(%arg0, %arg1, %arg2) : (vector<64xsi32>, vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vsub_v64_u32(%arg0: vector<64xui32>, %arg1: vector<64xui32>, %arg2: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vsub.u.x"(%arg0, %arg1, %arg2) : (vector<64xui32>, vector<64xui32>, vector<256xi1>) -> vector<64xui32>
    "test.test"(%0) : (vector<64xui32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vrelu_v128_f16(%arg0: vector<128xf16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vrelu.x"(%arg0, %arg1) : (vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vrelu_v64_f32(%arg0: vector<64xf32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vrelu.x"(%arg0, %arg1) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vrelu_v128_s32(%arg0: vector<64xsi32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vrelu.x"(%arg0, %arg1) : (vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vabs_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vabs.x"(%arg0, %arg1) : (vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vabs_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vabs.x"(%arg0, %arg1) : (vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vabs_v128_f16(%arg0: vector<128xf16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vabs.x"(%arg0, %arg1) : (vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vabs_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vabs.x"(%arg0, %arg1) : (vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vabs_v64_f32(%arg0: vector<64xf32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vabs.x"(%arg0, %arg1) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vneg_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vneg.x"(%arg0, %arg1) : (vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vneg_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vneg.x"(%arg0, %arg1) : (vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vneg_v128_f16(%arg0: vector<128xf16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vneg.x"(%arg0, %arg1) : (vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vneg_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vneg.x"(%arg0, %arg1) : (vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vneg_v64_f32(%arg0: vector<64xf32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vneg.x"(%arg0, %arg1) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vnot_v256_s8(%arg0: vector<256xsi8>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vnot.x"(%arg0, %arg1) : (vector<256xsi8>, vector<256xi1>) -> vector<256xsi8>
    "test.test"(%0) : (vector<256xsi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vnot_v128_s16(%arg0: vector<128xsi16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vnot.x"(%arg0, %arg1) : (vector<128xsi16>, vector<256xi1>) -> vector<128xsi16>
    "test.test"(%0) : (vector<128xsi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vnot_v128_f16(%arg0: vector<128xf16>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vnot.x"(%arg0, %arg1) : (vector<128xf16>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%0) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vnot_v64_s32(%arg0: vector<64xsi32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vnot.x"(%arg0, %arg1) : (vector<64xsi32>, vector<256xi1>) -> vector<64xsi32>
    "test.test"(%0) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vnot_v64_f32(%arg0: vector<64xf32>, %arg1: vector<256xi1>) {
    %0 = "hivm_regbaseintrins.intr.hivm.vnot.x"(%arg0, %arg1) : (vector<64xf32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%0) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v64_f32(%arg0: memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64f32"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xf32>
    "test.test"(%9) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v32_u64(%arg0: memref<32xui64, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<32xui64, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i64
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i64
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v32u64"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<32xi64>
    "test.test"(%9) : (vector<32xi64>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v32_s64(%arg0: memref<32xsi64, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<32xsi64, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i64
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i64
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v32s64"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<32xi64>
    "test.test"(%9) : (vector<32xi64>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v64_s32(%arg0: memref<64xsi32, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<64xsi32, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64s32"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    "test.test"(%9) : (vector<64xi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v64_u32(%arg0: memref<64xui32, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<64xui32, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v64u32"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<64xi32>
    "test.test"(%9) : (vector<64xi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v128_s16(%arg0: memref<128xsi16, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<128xsi16, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128s16"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xi16>
    "test.test"(%9) : (vector<128xi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v128_u16(%arg0: memref<128xui16, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<128xui16, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128u16"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xi16>
    "test.test"(%9) : (vector<128xi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v256_s8(%arg0: memref<256xsi8, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<256xsi8, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v256s8"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi8>
    "test.test"(%9) : (vector<256xi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v256_u8(%arg0: memref<256xui8, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<256xui8, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v256u8"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<256xi8>
    "test.test"(%9) : (vector<256xi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v128_f16(%arg0: memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<128xf16, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128f16"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xf16>
    "test.test"(%9) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_load_v128_bf16(%arg0: memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<ub>>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<128xbf16, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = "hivm_regbaseintrins.intr.hivm.vldsx1.v128bf16"(%5, %6, %8, %7) : (!llvm.ptr<6>, i32, i32, i32) -> vector<128xbf16>
    "test.test"(%9) : (vector<128xbf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_store_v64_f32(%arg0: memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<ub>>, %arg1: vector<64xf32>, %arg2: vector<256xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %5 = llvm.getelementptr %4[%1] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %6 = llvm.mlir.constant(0 : i32) : i32
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = llvm.mlir.constant(2 : i32) : i32
    "hivm_regbaseintrins.intr.hivm.vstsx1.v64f32"(%arg1, %5, %6, %8, %7, %arg2) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, i32, vector<256xi1>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v64_s32(%arg0: memref<64x1xsi32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<64xi32>, %arg3: vector<64xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<64x1xsi32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<64xi1> to vector<256xi1>
    %10 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v64s32"(%8, %arg2, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %11 = builtin.unrealized_conversion_cast %10 : vector<64xi32> to vector<64xsi32>
    "test.test"(%11) : (vector<64xsi32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v64_u32(%arg0: memref<64x1xui32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<64xi32>, %arg3: vector<64xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<64x1xui32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i32
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<64xi1> to vector<256xi1>
    %10 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v64u32"(%8, %arg2, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<64xi32>
    %11 = builtin.unrealized_conversion_cast %10 : vector<64xi32> to vector<64xui32>
    "test.test"(%11) : (vector<64xui32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v128_s16(%arg0: memref<128x1xsi16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<128xi16>, %arg3: vector<128xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<128x1xsi16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<128xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<128xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v128s16"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xi16>
    "test.test"(%12) : (vector<128xi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v128_u16(%arg0: memref<128x1xui16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<128xi16>, %arg3: vector<128xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<128x1xui16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i16
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<128xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<128xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v128u16"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xi16>
    "test.test"(%12) : (vector<128xi16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v256_s8(%arg0: memref<256x1xsi8, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<256xi16>, %arg3: vector<256xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<256x1xsi8, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<256xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<256xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v256s8"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xi16>
    %13 = llvm.bitcast %12 : vector<128xi16> to vector<256xi8>
    "test.test"(%13) : (vector<256xi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v256_u8(%arg0: memref<256x1xui8, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<256xi16>, %arg3: vector<256xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<256x1xui8, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i8
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<256xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<256xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v256u8"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xi16>
    %13 = llvm.bitcast %12 : vector<128xi16> to vector<256xi8>
    "test.test"(%13) : (vector<256xi8>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v64_f32(%arg0: memref<64x1xf32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<64xi32>, %arg3: vector<64xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<64x1xf32, strided<[32, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %5 = llvm.mlir.constant(32 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<64xi1> to vector<256xi1>
    %10 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v64f32"(%8, %arg2, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<64xf32>
    "test.test"(%10) : (vector<64xf32>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v128_f16(%arg0: memref<128x1xf16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<128xi16>, %arg3: vector<128xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<128x1xf16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<128xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<128xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v128f16"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xf16>
    "test.test"(%12) : (vector<128xf16>) -> ()
    return
  }
}

// -----
module {
  func.func @test_gather_v128_bf16(%arg0: memref<128x1xbf16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<128xi16>, %arg3: vector<128xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<128x1xbf16, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, bf16
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<128xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<128xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v128bf16"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xbf16>
    "test.test"(%12) : (vector<128xbf16>) -> ()
    return
  }
}

// -----
#map = affine_map<(d0, d1)[s0] -> (d0 * 1024 + d1 + s0)>
#map1 = affine_map<(d0, d1)[s0] -> (d0 * 512 + d1 + s0)>
module {
  func.func @test_gather_v256_f8e5m2(%arg0: memref<256x1xf8E5M2, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, %arg1: index, %arg2: vector<256xi16>, %arg3: vector<256xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : index to i64
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<256x1xf8E5M2, strided<[16, 1], offset: ?>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %2 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %1[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.getelementptr %2[%3] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f8E5M2
    %5 = llvm.mlir.constant(16 : index) : i64
    %6 = llvm.mul %0, %5 : i64
    %7 = llvm.add %6, %0 : i64
    %8 = llvm.getelementptr %4[%7] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f8E5M2
    %9 = builtin.unrealized_conversion_cast %arg3 : vector<256xi1> to vector<256xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<256xi16> to vector<128xi16>
    %11 = llvm.bitcast %10 : vector<128xi16> to vector<64xi32>
    %12 = "hivm_regbaseintrins.intr.hivm.vgather2_v300.v256f8e5m2"(%8, %11, %9) : (!llvm.ptr<6>, vector<64xi32>, vector<256xi1>) -> vector<128xi16>
    %13 = llvm.bitcast %12 : vector<128xi16> to vector<256xf8E5M2>
    "test.test"(%13) : (vector<256xf8E5M2>) -> ()
    return
  }
  func.func @test_vsstb_rank_three(%arg0: memref<4x1x16xf16, strided<[1024, 16, 1]>, #hivm.address_space<ub>>, %arg1: vector<128xi1>, %arg2: vector<128xf16>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<4x1x16xf16, strided<[1024, 16, 1]>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)>
    %1 = llvm.mlir.constant(0 : index) : i64
    %2 = llvm.mlir.constant(1024 : index) : i64
    %3 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<3 x i64>, array<3 x i64>)> 
    %4 = llvm.mlir.constant(1024 : index) : i64
    %5 = llvm.mul %1, %4 : i64
    %6 = llvm.mlir.constant(16 : index) : i64
    %7 = llvm.mul %1, %6 : i64
    %8 = llvm.add %5, %7 : i64
    %9 = llvm.add %8, %1 : i64
    %10 = llvm.getelementptr %3[%9] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %11 = llvm.mlir.constant(4194304 : i32) : i32
    %12 = llvm.mlir.constant(0 : i32) : i32
    %13 = builtin.unrealized_conversion_cast %arg1 : vector<128xi1> to vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vsstb.v128f16"(%arg2, %10, %11, %12, %13) : (vector<128xf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    return
  }
  func.func @test_vsstb_v128_f16(%arg0: memref<4x16xf16, #map, #hivm.address_space<ub>>, %arg1: vector<64xi1>, %arg2: vector<64xf16>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<4x16xf16, #map, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1024 : index) : i64
    %2 = llvm.mlir.constant(0 : index) : i64
    %3 = builtin.unrealized_conversion_cast %arg2 : vector<64xf16> to vector<128xf16>
    %4 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.getelementptr %4[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %7 = llvm.mlir.constant(1024 : index) : i64
    %8 = llvm.mul %2, %7 : i64
    %9 = llvm.add %8, %2 : i64
    %10 = llvm.getelementptr %6[%9] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %11 = llvm.mlir.constant(4194304 : i32) : i32
    %12 = llvm.mlir.constant(0 : i32) : i32
    %13 = builtin.unrealized_conversion_cast %arg1 : vector<64xi1> to vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vsstb.v128f16"(%3, %10, %11, %12, %13) : (vector<128xf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    return
  }
  func.func @test_vsstb_v128_bf16(%arg0: memref<4x16xf16, #map, #hivm.address_space<ub>>, %arg1: vector<64xi1>, %arg2: vector<64xbf16>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<4x16xf16, #map, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(1024 : index) : i64
    %2 = llvm.mlir.constant(0 : index) : i64
    %3 = builtin.unrealized_conversion_cast %arg2 : vector<64xbf16> to vector<128xbf16>
    %4 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.getelementptr %4[%5] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %7 = llvm.mlir.constant(1024 : index) : i64
    %8 = llvm.mul %2, %7 : i64
    %9 = llvm.add %8, %2 : i64
    %10 = llvm.getelementptr %6[%9] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f16
    %11 = llvm.mlir.constant(4194304 : i32) : i32
    %12 = llvm.mlir.constant(0 : i32) : i32
    %13 = builtin.unrealized_conversion_cast %arg1 : vector<64xi1> to vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vsstb.v128bf16"(%3, %10, %11, %12, %13) : (vector<128xbf16>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    return
  }
  func.func @test_vsstb_v64_f32(%arg0: memref<8x8xf32, #map1, #hivm.address_space<ub>>, %arg1: vector<64xi1>, %arg2: vector<64xf32>) {
    %0 = builtin.unrealized_conversion_cast %arg0 : memref<8x8xf32, #map1, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.mlir.constant(512 : index) : i64
    %2 = llvm.mlir.constant(0 : index) : i64
    %3 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[2] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.getelementptr %3[%4] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %6 = llvm.mlir.constant(512 : index) : i64
    %7 = llvm.mul %2, %6 : i64
    %8 = llvm.add %7, %2 : i64
    %9 = llvm.getelementptr %5[%8] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, f32
    %10 = llvm.mlir.constant(4194304 : i32) : i32
    %11 = llvm.mlir.constant(0 : i32) : i32
    %12 = builtin.unrealized_conversion_cast %arg1 : vector<64xi1> to vector<256xi1>
    "hivm_regbaseintrins.intr.hivm.vsstb.v64f32"(%arg2, %9, %10, %11, %12) : (vector<64xf32>, !llvm.ptr<6>, i32, i32, vector<256xi1>) -> ()
    return
  }
}

// -----
module {
  func.func @test_vshls$i8$subvl(%arg0: vector<128xi8>) -> vector<128xi8> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i8) : i8
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<128xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<128xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<128xi8> to vector<256xi8>
    %8 = llvm.mlir.constant(7 : i16) : i16
    %9 = "hivm_regbaseintrins.intr.hivm.vshls.u.x"(%7, %8, %6) : (vector<256xi8>, i16, vector<256xi1>) -> vector<256xi8>
    %10 = builtin.unrealized_conversion_cast %9 : vector<256xi8> to vector<128xi8>
    return %10 : vector<128xi8>
  }
}

// -----
module {
  func.func @test_vshrs$i8$subvl(%arg0: vector<128xi8>) -> vector<128xi8> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i8) : i8
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<128xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<128xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<128xi8> to vector<256xi8>
    %8 = llvm.mlir.constant(7 : i16) : i16
    %9 = "hivm_regbaseintrins.intr.hivm.vshrs.u.x"(%7, %8, %6) : (vector<256xi8>, i16, vector<256xi1>) -> vector<256xi8>
    %10 = builtin.unrealized_conversion_cast %9 : vector<256xi8> to vector<128xi8>
    return %10 : vector<128xi8>
  }
}

// -----
module {
  func.func @test_vshls$i16$subvl(%arg0: vector<64xi16>) -> vector<64xi16> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i16) : i16
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%2, %3) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<64xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<64xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<64xi16> to vector<128xi16>
    %8 = "hivm_regbaseintrins.intr.hivm.vshls.u.x"(%7, %1, %6) : (vector<128xi16>, i16, vector<256xi1>) -> vector<128xi16>
    %9 = builtin.unrealized_conversion_cast %8 : vector<128xi16> to vector<64xi16>
    return %9 : vector<64xi16>
  }
}

// -----
module {
  func.func @test_vshrs$i16$subvl(%arg0: vector<64xi16>) -> vector<64xi16> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i16) : i16
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%2, %3) {mask_bit_width = 16 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<64xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<64xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<64xi16> to vector<128xi16>
    %8 = "hivm_regbaseintrins.intr.hivm.vshrs.u.x"(%7, %1, %6) : (vector<128xi16>, i16, vector<256xi1>) -> vector<128xi16>
    %9 = builtin.unrealized_conversion_cast %8 : vector<128xi16> to vector<64xi16>
    return %9 : vector<64xi16>
  }
}

// -----
module {
  func.func @test_vshls$i32$subvl(%arg0: vector<32xi32>) -> vector<32xi32> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i32) : i32
    %2 = llvm.mlir.constant(12 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<32xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<32xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<32xi32> to vector<64xi32>
    %8 = llvm.mlir.constant(7 : i16) : i16
    %9 = "hivm_regbaseintrins.intr.hivm.vshls.u.x"(%7, %8, %6) : (vector<64xi32>, i16, vector<256xi1>) -> vector<64xi32>
    %10 = builtin.unrealized_conversion_cast %9 : vector<64xi32> to vector<32xi32>
    return %10 : vector<32xi32>
  }
}

// -----
module {
  func.func @test_vshrs$i32$subvl(%arg0: vector<32xi32>) -> vector<32xi32> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i32) : i32
    %2 = llvm.mlir.constant(12 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%2, %3) {mask_bit_width = 32 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = builtin.unrealized_conversion_cast %4 : vector<256xi1> to vector<32xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<32xi1> to vector<256xi1>
    %7 = builtin.unrealized_conversion_cast %arg0 : vector<32xi32> to vector<64xi32>
    %8 = llvm.mlir.constant(7 : i16) : i16
    %9 = "hivm_regbaseintrins.intr.hivm.vshrs.u.x"(%7, %8, %6) : (vector<64xi32>, i16, vector<256xi1>) -> vector<64xi32>
    %10 = builtin.unrealized_conversion_cast %9 : vector<64xi32> to vector<32xi32>
    return %10 : vector<32xi32>
  }
}

// -----
module {
  func.func @test_vshls$i8$eqvl(%arg0: vector<256xi8>) -> vector<256xi8> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i8) : i8
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = llvm.mlir.constant(7 : i16) : i16
    %6 = "hivm_regbaseintrins.intr.hivm.vshls.u.x"(%arg0, %5, %4) : (vector<256xi8>, i16, vector<256xi1>) -> vector<256xi8>
    return %6 : vector<256xi8>
  }
}

// -----
module {
  func.func @test_vshls$i32$eqvl(%arg0: vector<64xi32>) -> vector<64xi32> {
    %0 = llvm.mlir.constant(false) : i1
    %1 = llvm.mlir.constant(7 : i32) : i32
    %2 = llvm.mlir.constant(7 : i32) : i32
    %3 = llvm.mlir.constant(0 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.pge.b8"(%2, %3) {mask_bit_width = 8 : i32, mask_op_idx = 0 : i32} : (i32, i32) -> vector<256xi1>
    %5 = llvm.mlir.constant(7 : i16) : i16
    %6 = "hivm_regbaseintrins.intr.hivm.vshls.u.x"(%arg0, %5, %4) : (vector<64xi32>, i16, vector<256xi1>) -> vector<64xi32>
    return %6 : vector<64xi32>
  }
}

