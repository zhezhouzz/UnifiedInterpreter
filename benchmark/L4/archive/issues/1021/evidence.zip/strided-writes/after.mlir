module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">} {
  func.func @one_row(%arg0: vector<1x8xf32>, %arg1: memref<?x16xf32, strided<[?, 1], offset: ?>, #hivm.address_space<ub>>, %arg2: index) {
    %c0 = arith.constant 0 : index
    %0 = builtin.unrealized_conversion_cast %arg0 : vector<1x8xf32> to vector<8xf32>
    %1 = ave.hir.pge <ALL> : vector<8xi1>
    ave.hir.masked_store <NORM_B32> %arg1[%arg2, %c0], %1, %0 {ave.unaligned_ub_access = #ave.unaligned_ub_access} : memref<?x16xf32, strided<[?, 1], offset: ?>, #hivm.address_space<ub>>, vector<8xi1>, vector<8xf32>
    return
  }
  func.func @strided_blocks(%arg0: vector<4x8xf32>, %arg1: memref<4x8xf32, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = builtin.unrealized_conversion_cast %arg0 : vector<4x8xf32> to vector<32xf32>
    %1 = ave.hir.pge <ALL> : vector<32xi1>
    %c16 = arith.constant 16 : index
    ave.hir.store_with_stride %arg1[%c0, %c0], %c16, %1, %0 : memref<4x8xf32, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, vector<32xi1>, vector<32xf32>
    return
  }
  func.func @first_lane(%arg0: vector<2x32xf32>, %arg1: memref<2x32xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = ave.hir.pge <VL1> : vector<64xi1>
    %1 = builtin.unrealized_conversion_cast %0 : vector<64xi1> to vector<2x32xi1>
    %2 = builtin.unrealized_conversion_cast %arg0 : vector<2x32xf32> to vector<64xf32>
    %3 = builtin.unrealized_conversion_cast %0 : vector<64xi1> to vector<32xi1>
    ave.hir.masked_store <ONEPT_B32> %arg1[%c0, %c0], %3, %2 {ave.unaligned_ub_access = #ave.unaligned_ub_access} : memref<2x32xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>, vector<32xi1>, vector<64xf32>
    return
  }
  func.func @first_row_prefix(%arg0: vector<2x32xf32>, %arg1: memref<2x32xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = ave.hir.pge <VL8> : vector<64xi1>
    %1 = builtin.unrealized_conversion_cast %0 : vector<64xi1> to vector<2x32xi1>
    %2 = builtin.unrealized_conversion_cast %arg0 : vector<2x32xf32> to vector<64xf32>
    %3 = builtin.unrealized_conversion_cast %0 : vector<64xi1> to vector<32xi1>
    ave.hir.masked_store <NORM_B32> %arg1[%c0, %c0], %3, %2 {ave.unaligned_ub_access = #ave.unaligned_ub_access} : memref<2x32xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>, vector<32xi1>, vector<64xf32>
    return
  }
}

