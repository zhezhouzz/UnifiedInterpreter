#map = affine_map<(d0, d1) -> (d1, d0)>
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">} {
  func.func private @transpose2d_fused_0(%arg0: memref<64x16xf32, #hivm.address_space<ub>>, %arg1: memref<16x64xf32, #hivm.address_space<ub>>) attributes {hivm.vector_function, no_inline} {
    %cst = arith.constant 0.000000e+00 : f32
    %c0 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    scf.for %arg2 = %c0 to %c16 step %c1 {
      %subview = memref.subview %arg0[0, %arg2] [64, 1] [1, 1] : memref<64x16xf32, #hivm.address_space<ub>> to memref<64x1xf32, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>
      %subview_0 = memref.subview %arg1[%arg2, 0] [1, 64] [1, 1] : memref<16x64xf32, #hivm.address_space<ub>> to memref<1x64xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
      %0 = vector.transfer_read %subview[%c0, %c0], %cst {in_bounds = [true, true], permutation_map = #map} : memref<64x1xf32, strided<[16, 1], offset: ?>, #hivm.address_space<ub>>, vector<1x64xf32>
      vector.transfer_write %0, %subview_0[%c0, %c0] {in_bounds = [true, true]} : vector<1x64xf32>, memref<1x64xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>
    }
    return
  }
  func.func @transpose2d(%arg0: memref<64x16xf32, #hivm.address_space<ub>>, %arg1: memref<16x64xf32, #hivm.address_space<ub>>) {
    call @transpose2d_fused_0(%arg0, %arg1) {hivm.vector_function, no_inline} : (memref<64x16xf32, #hivm.address_space<ub>>, memref<16x64xf32, #hivm.address_space<ub>>) -> ()
    return
  }
}

// -----
#map = affine_map<(d0, d1, d2) -> (d1, d0, d2)>
module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">} {
  func.func private @transpose3d_fused_0(%arg0: memref<64x4x16xf16, #hivm.address_space<ub>>, %arg1: memref<4x64x16xf16, #hivm.address_space<ub>>) attributes {hivm.vector_function, no_inline} {
    %cst = arith.constant 0.000000e+00 : f16
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c64 = arith.constant 64 : index
    scf.for %arg2 = %c0 to %c4 step %c1 {
      scf.for %arg3 = %c0 to %c64 step %c1 {
        %subview = memref.subview %arg0[%arg3, %arg2, 0] [1, 1, 16] [1, 1, 1] : memref<64x4x16xf16, #hivm.address_space<ub>> to memref<1x1x16xf16, strided<[64, 16, 1], offset: ?>, #hivm.address_space<ub>>
        %subview_0 = memref.subview %arg1[%arg2, %arg3, 0] [1, 1, 16] [1, 1, 1] : memref<4x64x16xf16, #hivm.address_space<ub>> to memref<1x1x16xf16, strided<[1024, 16, 1], offset: ?>, #hivm.address_space<ub>>
        %0 = vector.transfer_read %subview[%c0, %c0, %c0], %cst {in_bounds = [true, true, true], permutation_map = #map} : memref<1x1x16xf16, strided<[64, 16, 1], offset: ?>, #hivm.address_space<ub>>, vector<1x1x16xf16>
        vector.transfer_write %0, %subview_0[%c0, %c0, %c0] {in_bounds = [true, true, true]} : vector<1x1x16xf16>, memref<1x1x16xf16, strided<[1024, 16, 1], offset: ?>, #hivm.address_space<ub>>
      }
    }
    return
  }
  func.func @transpose3d(%arg0: memref<64x4x16xf16, #hivm.address_space<ub>>, %arg1: memref<4x64x16xf16, #hivm.address_space<ub>>) {
    call @transpose3d_fused_0(%arg0, %arg1) {hivm.vector_function, no_inline} : (memref<64x4x16xf16, #hivm.address_space<ub>>, memref<4x64x16xf16, #hivm.address_space<ub>>) -> ()
    return
  }
}

