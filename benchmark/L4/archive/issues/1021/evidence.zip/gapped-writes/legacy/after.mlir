module {
  func.func @gapped_rows(%arg0: vector<16x4xf32>, %arg1: memref<16x4xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = builtin.unrealized_conversion_cast %arg0 : vector<16x4xf32> to vector<64xf32>
    %1 = ave.hir.pge <ALL> : vector<64xi1>
    ave.hir.masked_store <NORM_B32> %arg1[%c0, %c0], %1, %0 : memref<16x4xf32, strided<[64, 1], offset: ?>, #hivm.address_space<ub>>, vector<64xi1>, vector<64xf32>
    return
  }
}

// -----
module {
  func.func @gapped_planes(%arg0: vector<4x2x16xf16>, %arg1: memref<4x2x16xf16, strided<[1024, 16, 1], offset: ?>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = builtin.unrealized_conversion_cast %arg0 : vector<4x2x16xf16> to vector<128xf16>
    %1 = ave.hir.pge <ALL> : vector<128xi1>
    ave.hir.masked_store <NORM_B16> %arg1[%c0, %c0, %c0], %1, %0 : memref<4x2x16xf16, strided<[1024, 16, 1], offset: ?>, #hivm.address_space<ub>>, vector<128xi1>, vector<128xf16>
    return
  }
}

// -----
module {
  func.func @partial_native_block(%arg0: vector<4x4xf32>, %arg1: memref<4x8xf32, strided<[16, 1]>, #hivm.address_space<ub>>) {
    %c0 = arith.constant 0 : index
    %0 = builtin.unrealized_conversion_cast %arg0 : vector<4x4xf32> to vector<16xf32>
    %1 = ave.hir.pge <ALL> : vector<16xi1>
    %c16 = arith.constant 16 : index
    ave.hir.store_with_stride %arg1[%c0, %c0], %c16, %1, %0 : memref<4x8xf32, strided<[16, 1]>, #hivm.address_space<ub>>, vector<16xi1>, vector<16xf32>
    return
  }
}

