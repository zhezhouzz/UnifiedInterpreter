module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 32 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 32 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 64 : i32>, #dlti.dl_entry<"UB_SIZE", 2031616 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-c310">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 16 : i32>>>, hacc.target = #hacc.target<"Ascend910_9589">} {
  func.func @pb16(%arg0: memref<32xi1, strided<[1], offset: 32>, #hivm.address_space<ub>>, %arg1: memref<256xi1, #hivm.address_space<ub>>, %arg2: vector<128xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : memref<256xi1, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<32xi1, strided<[1], offset: 32>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.mlir.constant(0 : index) : i64
    %3 = llvm.mlir.constant(32 : i32) : i32
    %4 = "hivm_regbaseintrins.intr.hivm.plt.b16.v300"(%3) : (i32) -> !llvm.struct<(vector<256xi1>, i32)>
    %5 = llvm.extractvalue %4[0] {mask_bit_width = 16 : i32} : !llvm.struct<(vector<256xi1>, i32)> 
    %6 = builtin.unrealized_conversion_cast %5 : vector<256xi1> to vector<128xi1>
    %7 = llvm.mlir.constant(0 : i32) : i32
    %8 = "hivm_regbaseintrins.intr.hivm.pge.b16"(%7, %7) {mask_bit_width = 16 : i32} : (i32, i32) -> vector<256xi1>
    %9 = builtin.unrealized_conversion_cast %8 : vector<256xi1> to vector<128xi1>
    %10 = builtin.unrealized_conversion_cast %arg2 : vector<128xi1> to vector<256xi1>
    %11 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.mlir.constant(32 : index) : i64
    %13 = llvm.mlir.constant(8 : index) : i64
    %14 = llvm.udiv %12, %13  : i64
    %15 = llvm.getelementptr %11[%14] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %16 = llvm.getelementptr %15[%2] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %17 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %18 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%10, %16, %17) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %19 = llvm.extractvalue %18[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %20 = llvm.extractvalue %18[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%19, %20, %7, %7) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %21 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %22 = llvm.getelementptr %21[%2] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %23 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %24 = "hivm_regbaseintrins.intr.hivm.pstu.b16"(%10, %22, %23) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %25 = llvm.extractvalue %24[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %26 = llvm.extractvalue %24[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%25, %26, %7, %7) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    return
  }
  func.func @pb32(%arg0: memref<16xi1, strided<[1], offset: 16>, #hivm.address_space<ub>>, %arg1: memref<256xi1, #hivm.address_space<ub>>, %arg2: vector<64xi1>) {
    %0 = builtin.unrealized_conversion_cast %arg1 : memref<256xi1, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %1 = builtin.unrealized_conversion_cast %arg0 : memref<16xi1, strided<[1], offset: 16>, #hivm.address_space<ub>> to !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)>
    %2 = llvm.mlir.constant(0 : index) : i64
    %3 = llvm.mlir.constant(6 : i32) : i32
    %4 = llvm.mlir.constant(0 : i32) : i32
    %5 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%3, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %6 = builtin.unrealized_conversion_cast %5 : vector<256xi1> to vector<64xi1>
    %7 = "hivm_regbaseintrins.intr.hivm.pge.b32"(%4, %4) {mask_bit_width = 32 : i32} : (i32, i32) -> vector<256xi1>
    %8 = builtin.unrealized_conversion_cast %7 : vector<256xi1> to vector<64xi1>
    %9 = builtin.unrealized_conversion_cast %arg2 : vector<64xi1> to vector<256xi1>
    %10 = llvm.extractvalue %1[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.mlir.constant(16 : index) : i64
    %12 = llvm.mlir.constant(8 : index) : i64
    %13 = llvm.udiv %11, %12  : i64
    %14 = llvm.getelementptr %10[%13] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %15 = llvm.getelementptr %14[%2] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %16 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %17 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%9, %15, %16) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %18 = llvm.extractvalue %17[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %19 = llvm.extractvalue %17[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%18, %19, %4, %4) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    %20 = llvm.extractvalue %0[1] : !llvm.struct<(ptr<6>, ptr<6>, i64, array<1 x i64>, array<1 x i64>)> 
    %21 = llvm.getelementptr %20[%2] : (!llvm.ptr<6>, i64) -> !llvm.ptr<6>, i1
    %22 = "hivm_regbaseintrins.intr.hivm.init.vector.align.data"() : () -> vector<32xi8>
    %23 = "hivm_regbaseintrins.intr.hivm.pstu.b32"(%9, %21, %22) : (vector<256xi1>, !llvm.ptr<6>, vector<32xi8>) -> !llvm.struct<(vector<32xi8>, ptr<6>)>
    %24 = llvm.extractvalue %23[0] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    %25 = llvm.extractvalue %23[1] : !llvm.struct<(vector<32xi8>, ptr<6>)> 
    "hivm_regbaseintrins.intr.hivm.vstas"(%24, %25, %4, %4) : (vector<32xi8>, !llvm.ptr<6>, i32, i32) -> ()
    return
  }
}

