module attributes {dlti.target_system_spec = #dlti.target_system_spec<"NPU" : #hacc.target_device_spec<#dlti.dl_entry<"AI_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"CUBE_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"VECTOR_CORE_COUNT", 36 : i32>, #dlti.dl_entry<"UB_SIZE", 2555904 : i32>, #dlti.dl_entry<"L1_SIZE", 4194304 : i32>, #dlti.dl_entry<"L0A_SIZE", 524288 : i32>, #dlti.dl_entry<"L0B_SIZE", 524288 : i32>, #dlti.dl_entry<"L0C_SIZE", 2097152 : i32>, #dlti.dl_entry<"UB_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L1_ALIGN_SIZE", 256 : i32>, #dlti.dl_entry<"L0C_ALIGN_SIZE", 4096 : i32>, #dlti.dl_entry<"MINIMAL_D_CACHE_SIZE", 262144 : i32>, #dlti.dl_entry<"MAXIMUM_D_CACHE_SIZE", 983040 : i32>, #dlti.dl_entry<"ARCH", "dav-920r1">, #dlti.dl_entry<"UB_BANK_GROUP_COUNT", 32 : i32>>>, hacc.target = #hacc.target<"Ascend960DT_968B7">} {
  func.func @rank_zero() -> f32 {
    %c0_i64 = arith.constant 0 : i64
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %cst = arith.constant 2.000000e+00 : f32
    %cst_0 = arith.constant 5.000000e+00 : f32
    %0 = hivm.hir.pointer_cast(%c32_i64) : memref<f32, #hivm.address_space<ub>>
    memref.store %cst_0, %0[] : memref<f32, #hivm.address_space<ub>>
    %1 = scf.for %arg0 = %c0 to %c2 step %c1 iter_args(%arg1 = %0) -> (memref<f32, #hivm.address_space<ub>>) {
      %3 = hivm.hir.pointer_cast(%c0_i64) : memref<f32, #hivm.address_space<ub>>
      memref.store %cst, %3[] : memref<f32, #hivm.address_space<ub>>
      %4 = memref.load %arg1[] : memref<f32, #hivm.address_space<ub>>
      %5 = memref.load %3[] : memref<f32, #hivm.address_space<ub>>
      %6 = arith.addf %4, %5 : f32
      memref.store %6, %3[] : memref<f32, #hivm.address_space<ub>>
      %7 = hivm.hir.pointer_cast(%c32_i64) : memref<f32, #hivm.address_space<ub>>
      %8 = memref.load %3[] : memref<f32, #hivm.address_space<ub>>
      memref.store %8, %7[] : memref<f32, #hivm.address_space<ub>>
      scf.yield %7 : memref<f32, #hivm.address_space<ub>>
    }
    %2 = memref.load %1[] : memref<f32, #hivm.address_space<ub>>
    return %2 : f32
  }
}

