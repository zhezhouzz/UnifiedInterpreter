#map = affine_map<()[s0, s1] -> (s0 - s1)>
module {
  func.func private @write(memref<?xf32>)
  func.func private @read(memref<?xf32>)
  func.func @return_partial_tile(%arg0: memref<?xf32>, %arg1: index) {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %0 = arith.addi %arg1, %c2 : index
    %1 = arith.cmpi sgt, %arg1, %c0 : index
    %2 = arith.select %1, %0, %c0 : index
    scf.for %arg2 = %c0 to %2 step %c1 {
      %3 = arith.subi %arg2, %c1 : index
      %4 = arith.cmpi sge, %arg2, %c0 : index
      %5 = arith.cmpi slt, %arg2, %arg1 : index
      %6 = arith.andi %4, %5 : i1
      annotation.mark %6 {hivm.preload_num = 1 : i32} : i1
      scf.if %6 {
        %11 = affine.apply #map()[%arg1, %arg2]
        %subview_0 = memref.subview %arg0[0] [%11] [1] : memref<?xf32> to memref<?xf32>
        func.call @write(%subview_0) : (memref<?xf32>) -> ()
      }
      %7 = affine.apply #map()[%arg1, %3]
      %subview = memref.subview %arg0[0] [%7] [1] : memref<?xf32> to memref<?xf32>
      %8 = arith.cmpi sge, %3, %c0 : index
      %9 = arith.cmpi slt, %3, %arg1 : index
      %10 = arith.andi %8, %9 : i1
      annotation.mark %10 {hivm.preload_num = 0 : i32} : i1
      scf.if %10 {
        func.call @read(%subview) : (memref<?xf32>) -> ()
      }
    } {hivm.max_preload_num = 2 : i32}
    return
  }
}

