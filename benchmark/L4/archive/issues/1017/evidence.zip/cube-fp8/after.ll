; ModuleID = '/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence/5ba46fddf9/cube-fp8/patched/tmp/probe.bc'
source_filename = "/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence/5ba46fddf9/cube-fp8/test.c"
target datalayout = "e-i1:8:32-i8:8:32-i16:16:32-i64:64-f16:16:32-v16:16-v32:32-n8:16:32:64-S64"
target triple = "hiipu64-hisilicon-cce"

; Function Attrs: nounwind memory(argmem: readwrite)
define dso_local void @regular(ptr addrspace(5) nocapture noundef writeonly %0, ptr addrspace(3) nocapture noundef readonly %1, ptr addrspace(4) nocapture noundef readonly %2) local_unnamed_addr #0 !dbg !6 {
  tail call void @llvm.hivm.MAD.e4m3e4m3.c310(ptr addrspace(5) %0, ptr addrspace(3) %1, ptr addrspace(4) %2, i64 -9223372036586209264), !dbg !10
  ret void, !dbg !14
}

; Function Attrs: nounwind
define dso_local void @regular_bias(ptr addrspace(5) noundef %0, ptr addrspace(3) nocapture noundef readonly %1, ptr addrspace(4) nocapture noundef readonly %2, i64 noundef %3) local_unnamed_addr #1 !dbg !15 {
  %5 = ptrtoint ptr addrspace(5) %0 to i64, !dbg !16
  %6 = and i64 %5, 4294967295, !dbg !19
  %7 = shl i64 %3, 32, !dbg !20
  %8 = or i64 %7, %6, !dbg !21
  %9 = inttoptr i64 %8 to ptr addrspace(5), !dbg !22
  tail call void @llvm.hivm.MAD.e5m2e4m3.c310(ptr addrspace(5) %9, ptr addrspace(3) %1, ptr addrspace(4) %2, i64 4611686018695954448), !dbg !23
  ret void, !dbg !24
}

; Function Attrs: nounwind memory(argmem: readwrite)
define dso_local void @microscaled(ptr addrspace(5) nocapture noundef writeonly %0, ptr addrspace(3) nocapture noundef readonly %1, ptr addrspace(4) nocapture noundef readonly %2) local_unnamed_addr #0 !dbg !25 {
  tail call void @llvm.hivm.MMAD.MX.e4m3e4m3(ptr addrspace(5) %0, ptr addrspace(3) %1, ptr addrspace(4) %2, i64 -9223372036586209264), !dbg !26
  ret void, !dbg !29
}

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @llvm.hivm.MAD.e4m3e4m3.c310(ptr addrspace(5) nocapture writeonly, ptr addrspace(3) nocapture readonly, ptr addrspace(4) nocapture readonly, i64) #2

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @llvm.hivm.MAD.e5m2e4m3.c310(ptr addrspace(5) nocapture writeonly, ptr addrspace(3) nocapture readonly, ptr addrspace(4) nocapture readonly, i64) #2

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @llvm.hivm.MMAD.MX.e4m3e4m3(ptr addrspace(5) nocapture writeonly, ptr addrspace(3) nocapture readonly, ptr addrspace(4) nocapture readonly, i64) #2

attributes #0 = { nounwind memory(argmem: readwrite) "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="dav-920r1-cube" "target-features"="+ATOMIC,+ArchV130,+AregRedefinable,+ArithmeticBf16,+AtomicForB8 ,+F8e4m3,+F8e5m2,+F8e6m2,+F8e8m0,+FFTSBlk,+Fp4e1m2x2,+Fp4e2m1x2,+LDExtRefine,+MOVX8,+MergeModeRefine,+SPR7bits,+SyncV,+dav-920r1-cube" }
attributes #1 = { nounwind "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="dav-920r1-cube" "target-features"="+ATOMIC,+ArchV130,+AregRedefinable,+ArithmeticBf16,+AtomicForB8 ,+F8e4m3,+F8e5m2,+F8e6m2,+F8e8m0,+FFTSBlk,+Fp4e1m2x2,+Fp4e2m1x2,+LDExtRefine,+MOVX8,+MergeModeRefine,+SPR7bits,+SyncV,+dav-920r1-cube" }
attributes #2 = { nounwind memory(argmem: readwrite) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "2026-10-20T10:24:52+08:00 clang version 15.0.5", isOptimized: true, runtimeVersion: 0, emissionKind: LineTablesOnly, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence/5ba46fddf9/cube-fp8/test.c", directory: "/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence/5ba46fddf9/cube-fp8/patched")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 4}
!4 = !{i32 7, !"frame-pointer", i32 2}
!5 = !{!"2026-10-20T10:24:52+08:00 clang version 15.0.5"}
!6 = distinct !DISubprogram(name: "regular", scope: !7, file: !7, line: 14, type: !8, scopeLine: 15, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!7 = !DIFile(filename: "test.c", directory: "/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence/5ba46fddf9/cube-fp8")
!8 = !DISubroutineType(types: !9)
!9 = !{}
!10 = !DILocation(line: 583, column: 7, scope: !11, inlinedAt: !13)
!11 = distinct !DISubprogram(name: "MmadCal<float, __fp8e4m3, __fp8e4m3>", scope: !12, file: !12, line: 558, type: !8, scopeLine: 559, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!12 = !DIFile(filename: "headers-5ba46fddf9/bishengir/lib/Template/lib/RegBase/Cube/include/ascendc_bisheng/utils/./kernel_operator_mm_impl.h", directory: "/home/hocky/analysis/a6-v2-independent-mrs-20261120/evidence")
!13 = distinct !DILocation(line: 16, column: 3, scope: !6)
!14 = !DILocation(line: 17, column: 1, scope: !6)
!15 = distinct !DISubprogram(name: "regular_bias", scope: !7, file: !7, line: 21, type: !8, scopeLine: 22, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!16 = !DILocation(line: 624, column: 10, scope: !17, inlinedAt: !18)
!17 = distinct !DISubprogram(name: "MmadCal<float, __fp8e5m2, __fp8e4m3>", scope: !12, file: !12, line: 591, type: !8, scopeLine: 593, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!18 = distinct !DILocation(line: 23, column: 3, scope: !15)
!19 = !DILocation(line: 624, column: 23, scope: !17, inlinedAt: !18)
!20 = !DILocation(line: 624, column: 65, scope: !17, inlinedAt: !18)
!21 = !DILocation(line: 624, column: 39, scope: !17, inlinedAt: !18)
!22 = !DILocation(line: 632, column: 11, scope: !17, inlinedAt: !18)
!23 = !DILocation(line: 632, column: 7, scope: !17, inlinedAt: !18)
!24 = !DILocation(line: 24, column: 1, scope: !15)
!25 = distinct !DISubprogram(name: "microscaled", scope: !7, file: !7, line: 28, type: !8, scopeLine: 29, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!26 = !DILocation(line: 579, column: 7, scope: !27, inlinedAt: !28)
!27 = distinct !DISubprogram(name: "MmadCal<float, AscendCBisheng::mx_fp8_e4m3_t, AscendCBisheng::mx_fp8_e4m3_t>", scope: !12, file: !12, line: 558, type: !8, scopeLine: 559, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0, retainedNodes: !9)
!28 = distinct !DILocation(line: 30, column: 3, scope: !25)
!29 = !DILocation(line: 31, column: 1, scope: !25)
